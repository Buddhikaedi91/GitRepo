
$configurationdata=@{
    AllNodes = @(
    @{PSDscAllowPlainTextPassword = $false})}

Configuration setupUsers {

    Param ()

    Import-DscResource -ModuleName PSDesiredStateConfiguration

$cred= ConvertTo-SecureString "P@ssw0rd@DSC123" -AsPlainText -Force
    Node 'localhost'
    {
        User “AzureDSCAdminUser” {
            
            UserName = “DSCAdminUser”
            Ensure = “Present”
            FullName = “DSC Admin”
            Password = $cred
            PasswordNeverExpires = $true
            
            }
    }
}


